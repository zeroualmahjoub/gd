from odoo import models, fields

class SchoolElearning(models.Model):
    _name = 'school.elearning'
    _description = 'Contenu e-Learning'

    title = fields.Char(string="Titre", required=True)
    description = fields.Text(string="Description")
    file = fields.Binary(string="Fichier")
    file_name = fields.Char(string="Nom du fichier")
    type = fields.Selection([
        ('pdf', 'PDF'),
        ('video', 'Vidéo'),
        ('link', 'Lien')
    ], string="Type de contenu", default="pdf")
    club_id = fields.Many2one('school.club', string="Club associé")
