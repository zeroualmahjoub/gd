from odoo import models, fields

class SchoolStudent(models.Model):
    _name = 'school.student'
    _description = 'Élève'

    name = fields.Char(string="Nom", required=True)
    email = fields.Char(string="Email")
    class_name = fields.Char(string="Classe")
    club_ids = fields.Many2many('school.club', string="Clubs")
