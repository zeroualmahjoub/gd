from odoo import models, fields

class SchoolClub(models.Model):
    _name = 'school.club'
    _description = 'Club Scolaire'

    name = fields.Char(string='Nom du club', required=True)
    description = fields.Text(string='Description')
    responsible_id = fields.Many2one('res.users', string='Responsable du club')
    student_ids = fields.Many2many('school.student', string='Élèves')
    content_ids = fields.One2many('school.elearning', 'club_id', string='Contenus e-Learning')
    project_ids = fields.One2many('school.project', 'club_id', string='Projets de classe')
