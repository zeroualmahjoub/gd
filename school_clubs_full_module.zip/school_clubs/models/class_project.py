from odoo import models, fields

class SchoolProject(models.Model):
    _name = 'school.project'
    _description = 'Projet de Classe'

    name = fields.Char(string="Titre du projet", required=True)
    description = fields.Text(string="Description")
    date_start = fields.Date(string="Date de début")
    date_end = fields.Date(string="Date de fin")
    student_ids = fields.Many2many('school.student', string="Élèves participants")
    club_id = fields.Many2one('school.club', string="Club")
    documents = fields.Binary(string="Documents")
    documents_name = fields.Char(string="Nom du document")
