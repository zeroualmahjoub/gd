{
    'name': 'Clubs Scolaires',
    'version': '1.0',
    'category': 'Education',
    'summary': 'Gérer les clubs, les élèves, les projets et le contenu e-learning',
    'author': 'TonNom',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/club_views.xml',
        'views/student_views.xml',
        'views/project_views.xml',
        'views/elearning_views.xml',
    ],
    'installable': True,
    'application': True,
}
