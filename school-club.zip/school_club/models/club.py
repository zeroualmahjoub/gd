from odoo import models, fields

class SchoolClub(models.Model):
    _name = 'school.club'
    _description = 'Club Scolaire'

    name = fields.Char(string='Nom du Club', required=True)
    description = fields.Text(string='Description')
    responsible_id = fields.Many2one('res.users', string='Responsable du Club')
    student_ids = fields.Many2many('school.student', string='Élèves Membres')
    project_ids = fields.One2many('school.project', 'club_id', string='Projets')
    elearning_content_ids = fields.One2many('school.elearning.content', 'club_id', string='Contenus e-Learning')
