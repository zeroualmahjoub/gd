from odoo import models, fields

class SchoolProject(models.Model):
    _name = 'school.project'
    _description = 'Projet de Classe'

    name = fields.Char(string='Nom du Projet', required=True)
    description = fields.Text(string='Description')
    club_id = fields.Many2one('school.club', string='Club')
    start_date = fields.Date(string='Date de Début')
    end_date = fields.Date(string='Date de Fin')
