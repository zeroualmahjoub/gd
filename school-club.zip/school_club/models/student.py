from odoo import models, fields

class SchoolStudent(models.Model):
    _name = 'school.student'
    _description = 'Élève'

    name = fields.Char(string='Nom complet', required=True)
    student_number = fields.Char(string='Numéro Élève', required=True)
    club_ids = fields.Many2many('school.club', string='Clubs')
