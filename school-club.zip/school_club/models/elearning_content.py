from odoo import models, fields

class ElearningContent(models.Model):
    _name = 'school.elearning.content'
    _description = 'Contenu e-Learning'

    name = fields.Char(string='Titre', required=True)
    description = fields.Text(string='Description')
    content_url = fields.Char(string='Lien du contenu')
    club_id = fields.Many2one('school.club', string='Club')
