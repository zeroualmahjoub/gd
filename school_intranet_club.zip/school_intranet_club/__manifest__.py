{
    "name": "School Intranet Club",
    "version": "1.0",
    "summary": "Gestion des clubs scolaires avec agenda et portail élèves.",
    "author": "Odoo 18 Dev Buddy",
    "depends": ["base", "portal"],
    "data": [
        "security/ir.model.access.csv",
        "views/menu.xml"
    ],
    "application": True,
    "license": "LGPL-3"
}
